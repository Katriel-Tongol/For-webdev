package com.example.InvestPro.model;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.InvestPro.R;
import com.example.InvestPro.DetailActivity;
import java.util.List;

public class PictureAdapter extends RecyclerView.Adapter<PictureAdapter.PictureViewHolder> {

    private final Context context;
    private final List<Picture> pictures;

    public PictureAdapter(Context context, List<Picture> pictures) {
        this.context = context;
        this.pictures = pictures;
    }

    @NonNull
    @Override
    public PictureViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_picture, parent, false);
        return new PictureViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PictureViewHolder holder, int position) {
        Picture picture = pictures.get(position);
        holder.itemImage.setImageResource(picture.getImageResourceId());
        holder.itemName.setText(picture.getName());
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("pictureId", picture.getId());
            intent.putExtra("imageResId", picture.getImageResourceId());
            intent.putExtra("name", picture.getName());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return pictures.size();
    }

    public static class PictureViewHolder extends RecyclerView.ViewHolder {
        ImageView itemImage;
        TextView itemName;

        public PictureViewHolder(@NonNull View itemView) {
            super(itemView);
            itemImage = itemView.findViewById(R.id.item_image);
            itemName = itemView.findViewById(R.id.item_name);
        }
    }
}
