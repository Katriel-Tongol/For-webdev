package com.example.InvestPro;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.InvestPro.R;
import com.example.InvestPro.model.Picture;
import  com.example.InvestPro.model.PictureAdapter;
import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends Fragment {

    private RecyclerView recyclerView;
    private List<Picture> pictures;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        recyclerView = view.findViewById(R.id.search_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        pictures = new ArrayList<>();
        pictures.add(new Picture("1", R.drawable.anycolor_st, "Anycolor", 0));
        pictures.add(new Picture("2", R.drawable.cover_st, "Cover Corp", 0));
        pictures.add(new Picture("3", R.drawable.eagame_st, "Electronic Arts", 0));
        pictures.add(new Picture("4", R.drawable.gw_st, "Games Workshop", 0));
        pictures.add(new Picture("5", R.drawable.ft_st, "Future Tech", 0));

        // dito mo nalang add yung mga pic for the thing lol

        PictureAdapter adapter = new PictureAdapter(getContext(), pictures);
        recyclerView.setAdapter(adapter);

        return view;
    }
}
