package com.example.InvestPro;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class login extends AppCompatActivity {

    private EditText emailText, passwordText;
    private Button loginButton;
    private TextView forgotLink, signupLink;
    private CheckBox revealPass;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();

        emailText = findViewById(R.id.login_email);
        passwordText = findViewById(R.id.login_pass);
        forgotLink = findViewById(R.id.forgot_link);
        signupLink = findViewById(R.id.signup_link);
        revealPass = findViewById(R.id.reveal_pass);
        loginButton = findViewById(R.id.login_button);

        revealPass.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                passwordText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            } else {
                passwordText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            }
            passwordText.setSelection(passwordText.getText().length());
        });

        loginButton.setOnClickListener(v -> loginUser());

        forgotLink.setOnClickListener(v -> {
            Intent intent = new Intent(login.this, forgetpass.class);
            startActivity(intent);
        });

        signupLink.setOnClickListener(v -> {
            Intent intent = new Intent(login.this, create.class);
            startActivity(intent);
        });
    }

    private void loginUser() {
        String email = emailText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            emailText.setError("Email is required");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwordText.setError("Password is required");
            return;
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        startMainActivity();
                    } else {
                        Toast.makeText(login.this, "Authentication failed.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void startMainActivity() {
        Intent intent = new Intent(login.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
