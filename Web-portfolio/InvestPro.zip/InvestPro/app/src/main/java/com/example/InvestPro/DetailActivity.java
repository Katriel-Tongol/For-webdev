package com.example.InvestPro;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DetailActivity extends AppCompatActivity {

    private ImageView detailImage;
    private TextView detailName;
    private EditText investmentInput;
    private Button addInvestmentButton;

    private DatabaseReference databaseReference;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        detailImage = findViewById(R.id.detailImage);
        detailName = findViewById(R.id.detailName);
        investmentInput = findViewById(R.id.investmentInput);
        addInvestmentButton = findViewById(R.id.addInvestmentButton);

        int imageResId = getIntent().getIntExtra("imageResId", 0);
        String name = getIntent().getStringExtra("name");
        String pictureId = getIntent().getStringExtra("pictureId");

        detailImage.setImageResource(imageResId);
        detailName.setText(name);

        userId = FirebaseAuth.getInstance().getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("users").child(userId).child("investments");

        addInvestmentButton.setOnClickListener(v -> {
            String input = investmentInput.getText().toString().trim();
            if (TextUtils.isEmpty(input)) {
                Toast.makeText(this, "Please enter an amount", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                float investment = Float.parseFloat(input);
                databaseReference.child(pictureId).setValue(investment)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(this, "Investment added!", Toast.LENGTH_SHORT).show();
                            investmentInput.setText(""); // Clear input after success
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(this, "Failed to add investment: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            e.printStackTrace(); // Log error for debugging
                        });
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
