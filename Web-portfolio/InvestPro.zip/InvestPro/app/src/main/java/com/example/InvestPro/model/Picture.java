package com.example.InvestPro.model; // or com.example.InvestPro.model if placed in a subpackage

public class Picture {
    private String id;
    private int imageResourceId; // Change to `String` if using URLs
    private String name;
    private float investment;

    // Constructor
    public Picture(String id, int imageResourceId, String name, float investment) {
        this.id = id;
        this.imageResourceId = imageResourceId;
        this.name = name;
        this.investment = investment;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    public void setImageResourceId(int imageResourceId) {
        this.imageResourceId = imageResourceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getInvestment() {
        return investment;
    }

    public void setInvestment(float investment) {
        this.investment = investment;
    }
}
