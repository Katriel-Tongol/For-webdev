package com.example.InvestPro;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.InvestPro.model.Picture;
import com.example.InvestPro.model.PictureAdapter;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private List<Picture> pictures;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.home_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        pictures = new ArrayList<>();
        pictures.add(new Picture("6", R.drawable.eagame_st, "Electronic Arts", 0));
        pictures.add(new Picture("7", R.drawable.gw_st, "West Wood Studios", 0));
        pictures.add(new Picture("8", R.drawable.ft_st, "Kanegawa Industries", 0));
        // :D

        PictureAdapter adapter = new PictureAdapter(getContext(), pictures);
        recyclerView.setAdapter(adapter);

        return view;
    }
}
