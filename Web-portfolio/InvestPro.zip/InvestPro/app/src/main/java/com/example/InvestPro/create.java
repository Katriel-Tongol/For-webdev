package com.example.InvestPro;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class create extends AppCompatActivity {

    private EditText regEmail, regPassword, regConfirmPassword;
    private Button regSignUp;
    private TextView regLogin;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        regEmail = findViewById(R.id.reg_email);
        regPassword = findViewById(R.id.reg_pass);
        regConfirmPassword = findViewById(R.id.reg_conpass);
        regSignUp = findViewById(R.id.reg_sign);
        regLogin = findViewById(R.id.reg_login);
        mAuth = FirebaseAuth.getInstance();

        regSignUp.setOnClickListener(v -> registerUser());
        regLogin.setOnClickListener(v -> returnToLogin());
    }

    private void registerUser() {
        String email = regEmail.getText().toString();
        String password = regPassword.getText().toString();
        String confirmPassword = regConfirmPassword.getText().toString();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) {
                FirebaseUser user = mAuth.getCurrentUser();
                updateUI(user);
            } else {
                Toast.makeText(create.this, "Registration Failed.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void returnToLogin() {
        Intent intent = new Intent(create.this, login.class);
        startActivity(intent);
        finish();
    }

    private void updateUI(FirebaseUser user) {
        if (user != null) {
            Intent intent = new Intent(create.this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
        }
    }
}
