package com.example.alonzo_katrial_c204;

import androidx.fragment.app.Fragment;
import android.os.Bundle;
import com.example.alonzo_katrial_c204.HomeFragment;
import com.example.alonzo_katrial_c204.AccountFragment;
import com.example.alonzo_katrial_c204.SearchFragment;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNav;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottomNav = findViewById(R.id.bottomNavigationView);
        if(savedInstanceState == null){
            loadFragment(new HomeFragment());
        }
        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            if(item.getItemId() == R.id.nav_home){
                selectedFragment = new HomeFragment();
            } else if (item.getItemId() == R.id.nav_acc) {
                selectedFragment = new AccountFragment();
            } else if (item.getItemId() == R.id.nav_search) {
                selectedFragment = new SearchFragment();
            }
            if(selectedFragment != null){
                loadFragment(selectedFragment);
            }
            return true;
        });
    }
    private void loadFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout3, fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

    }
}
